package org.javabuilders.swing.samples;

import java.awt.Cursor;
import java.util.List;
import java.util.Random;

import javax.swing.JOptionPane;

import org.javabuilders.swing.SwingJavaBuilder;
import org.javabuilders.swing.samples.resources.Defect;

import ca.odell.glazedlists.BasicEventList;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.GlazedLists;
import ca.odell.glazedlists.TextFilterator;

public class GlazedListsSamplePanel extends SamplePanel {

	private final EventList<Defect> defects = GlazedLists.threadSafeList(new BasicEventList<Defect>());
	
	private String[] states = {"Fixed","New","In Progress","Rejected","Works for me"};
	private String[] types = {"Bug","Enahncement","Documentation","Task","Question"};
	private String[] reporter = {"John Doe","Jane Doe","Jimmy Doenowski","Arnold Doenator","Sylvester Doellone"};
	private Random random = new Random();
	
	public GlazedListsSamplePanel() throws Exception {
		super();
		SwingJavaBuilder.build(this);
	}
	
	private void fillWithData() {
		final String value = JOptionPane.showInputDialog("How many rows of data?");
		if (value != null) {
			try {
				this.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
				
				defects.clear();
				
				Runnable r = new Runnable() {
					public void run() {
						Integer count = Integer.parseInt(value);
						for(int i = 0; i < count; i++) {
							Defect defect = new Defect();
							defect.setId(i);
							defect.setPriority(i % 10);
							defect.setType(types[random.nextInt(types.length)]);
							defect.setState(states[random.nextInt(states.length)]);
							defect.setReporter(reporter[random.nextInt(reporter.length)]);
							defect.setSummary("Some defect, numbered as " + i);
							defects.add(defect);
						}
					}
				};
				new Thread(r).start();
			} catch (NumberFormatException ex) {
				JOptionPane.showMessageDialog(this,"Not a valid number");
			} finally {
				this.setCursor(Cursor.getDefaultCursor());
			}
		}
	}
	
	//allows filtering by Reporter or State
	public class DefectTextFilterator implements TextFilterator<Defect> {
	    public void getFilterStrings(List<String> baseList, Defect defect) {
	        baseList.add(defect.getReporter());
	        baseList.add(defect.getState());
	    }
	}	


}
