package org.javabuilders.swing.samples;

import org.javabuilders.BuildResult;
import org.javabuilders.swing.SwingJavaBuilder;

@SuppressWarnings("serial")
public class MigLayoutPanel3 extends SamplePanel {

	@SuppressWarnings("unused")
	private BuildResult result = SwingJavaBuilder.build(this);
	
	public MigLayoutPanel3() throws Exception {
		super();
	}

}
