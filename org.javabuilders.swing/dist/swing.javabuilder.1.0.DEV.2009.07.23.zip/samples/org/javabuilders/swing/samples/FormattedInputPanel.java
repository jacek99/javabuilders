package org.javabuilders.swing.samples;

import javax.swing.JPanel;

import org.javabuilders.BuildResult;
import org.javabuilders.swing.SwingJavaBuilder;

/**
 * Tests for formatted input
 *
 */
public class FormattedInputPanel extends SamplePanel {

	private BuildResult result = SwingJavaBuilder.build(this);
	
	public FormattedInputPanel() throws Exception {
		super();
		// TODO Auto-generated constructor stub
	}

}